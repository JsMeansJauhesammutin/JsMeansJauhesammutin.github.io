package o1.adventure
import scala.collection.mutable.Buffer

class Person(val name: String, item : Option[Item]):
  private var lastHeard = -1
  private val dialog = Buffer[(String, Option[Int], Boolean)]()

  override def toString = this.name
  def addDialog(text: String, nextLine: Int, wasQuestion: Boolean) =
    val toAdd = (text, Some(nextLine), wasQuestion)
    dialog += toAdd
    this

  def addDialog(text: String, wasQuestion: Boolean) =
    val toAdd = (text, None, wasQuestion)
    dialog += toAdd
    this

  def addDialog(text: String, nextLine: Int) =
    val toAdd = (text, Some(nextLine), false)
    dialog += toAdd
    this

  def addDialog(text: String) =
    val toAdd = (text, None, false)
    dialog += toAdd
    this

  def questionAsked : Boolean = dialog.lift(lastHeard).exists(l => l._3)

  def repeat(player: Player): String =
    lastHeard = -1
    "Sure, I can do that. Right from the beginning: " + advance(player)

  def lastHeardLine(player: Player) : String =
    val lineO = dialog.lift(lastHeard)
    lineO match
      case None =>
        "I've said all I have to say. I can repeat, if you wish, though." +
          (item match
            case None => ""
            case Some(i) =>
              player.receive(i)
              " Now, here's what I wanted to give you: a " + i.name)
      case Some(line) => line._1

  def advance(player: Player) : String =
    if questionAsked then
      "Well, could you answer the question?"
    else
      val lineIndexO = dialog.lift(lastHeard).flatMap(l => l._2)
      lineIndexO match
        case None => lastHeard += 1
        case Some(lineIndex) => lastHeard = lineIndex
      lastHeardLine(player)

  def yes(player: Player) : String =
    if !questionAsked then
      "Huh, I didn't ask anything?"
    else
      lastHeard += 1
      lastHeardLine(player)

  def no(player: Player) : String =
    if !questionAsked then
      "Huh, I didn't ask anything?"
    else
      val lineIndexO = dialog.lift(lastHeard).flatMap(l => l._2)
      lineIndexO match
        case None => lastHeard += 1
        case Some(lineIndex) => lastHeard = lineIndex
      lastHeardLine(player)

end Person
