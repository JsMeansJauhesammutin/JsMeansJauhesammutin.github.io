package o1.adventure
import scala.collection.mutable.Buffer
import scala.collection.View.Tabulate
import scala.util.Random

class Ship(var shipX : Int, var shipY: Int, val width: Int, val height: Int):
  def addPerson(x : Int, y : Int, person: Person) = //assumes location is valid
    pieces(x)(y).addPerson(person)
  def pieces : Buffer[Buffer[Area]] =
    Tabulate(width)(x =>
    Tabulate(height)(y => Ship.seaGrid(shipX+x)(shipY+y)).toBuffer).toBuffer
  def validDirections =
    if width > height then
      Buffer("east","west")
    else
      Buffer("north","south")

  def sail(direction: String) : String =
    if validDirections.contains(direction) then
      val newX = direction match
        case "east" => shipX + 1
        case "west" => shipX - 1
        case other => shipX
      val newY = direction match
        case "north" => shipY - 1
        case "south" => shipY + 1
        case other => shipY
      if newX >= 0 & newY >= 0 & newX + width - 1 < Ship.seaSize & newY + height - 1 < Ship.seaSize then
        if Ship(newX, newY, width, height).pieces.flatten.forall(a=>Ship.getShip(a).forall(_==this)) then
          val old = pieces
          for
            i <- 0 until width
            j <- 0 until height
          do
            Ship.seaGrid(shipX + i)(shipY + j) = Ship.newSea
          shipX = newX
          shipY = newY
          for
            i <- 0 until width
            j <- 0 until height
          do
            Ship.seaGrid(shipX + i)(shipY + j) = old(i)(j)
          Ship.updateNeighbors()
          "The ship was moved succesfully."
        else
          "There was a ship in the way."
      else
        "The ship can't move there, it's outside the edge of the map."
    else
      "The ship can't move in that direction. It can only move forward or backward."
end Ship

object Ship:
  private val random = Random
  val allShips = Buffer[Ship]()
  def add (ship: Ship) =
    allShips += ship
  def getShip(location: Area) =
    allShips.find(ship => ship.pieces.flatten.contains(location))
  val seaSize = 4
  var seaGrid = Tabulate(Ship.seaSize)(i =>
    Tabulate(Ship.seaSize)(j => Area("Nulland", "The Isle of Nulland, where the player should never end up.")).toBuffer
  ).toBuffer

  val seaChoices = Buffer("You feel the waves.",
     "You smell the salt.",
     "You feel alone.",
     "You're soggy and cold.",
     "You're at home.")
  val shipChoices = Buffer("You hear the sea.",
     "You smell the rum.",
     "You smell gunpowder.",
     "You feel the warmt of the candles.")

  def newSea =
    Area("The Sea", "You are on the open sea. " + seaChoices(random.nextInt(seaChoices.size)))
  def newShipTile (i: Int, j: Int) =
     Area("Unknown Ship",
            "Your position on the current ship is ("+i+", "+j+"). " + shipChoices(random.nextInt(shipChoices.size)))

  def initSeagrid () =
    for i <- 0 until Ship.seaSize do
      for j <- 0 until Ship.seaSize do
        seaGrid(i)(j) = newSea
    for s <- allShips do
      for i <- 0 until s.width do
        for j <- 0 until s.height do
          seaGrid(s.shipX+i)(s.shipY+j) = newShipTile(i, j)
    updateNeighbors()

  def updateNeighbors () =
    for i <- 0 until seaSize do
      for j <- 0 until seaSize do
        seaGrid(i)(j).resetNeighbors()
    for i <- 0 until seaSize - 1 do
      for j <- 0 until seaSize do
        seaGrid(i)(j).setNeighbor("east", seaGrid(i+1)(j))
    for i <- 0 until seaSize do
      for j <- 0 until seaSize - 1 do
        seaGrid(i)(j).setNeighbor("south", seaGrid(i)(j+1))
    for i <- 1 until seaSize do
      for j <- 0 until seaSize do
        seaGrid(i)(j).setNeighbor("west", seaGrid(i-1)(j))
    for i <- 0 until seaSize do
      for j <- 1 until seaSize do
        seaGrid(i)(j).setNeighbor("north", seaGrid(i)(j-1))
end Ship