package o1.adventure
import scala.collection.mutable.Buffer

/** The class `Adventure` represents text adventure games. An adventure consists of a player and
  * a number of areas that make up the game world. It provides methods for playing the game one
  * turn at a time and for checking the state of the game.
  *
  * N.B. This version of the class has a lot of “hard-coded” information that pertains to a very
  * specific adventure game that involves a small trip through a twisted forest. All newly created
  * instances of class `Adventure` are identical to each other. To create other kinds of adventure
  * games, you will need to modify or replace the source code of this class. */
class Adventure:

  /** the name of the game */
  val title = "A Not-So Oceanic Voyage"

  Ship.add(Ship(0,0,1,2))
  Ship.add(Ship(2,0,2,1))
  val mainShip = Ship(1,1,2,1)
  Ship.add(mainShip)
  Ship.add(Ship(3,1,1,2))
  Ship.add(Ship(0,2,3,1))
  Ship.add(Ship(0,3,3,1))
  Ship.initSeagrid()
  val seaGrid = Ship.seaGrid

  /** The character who is the protagonist of the adventure and whom the real-life player controls. */
  val player = Player(mainShip.pieces(0)(0))
  val mapItem = Item("map", "Real time - Updates automatically when the ships move. Shows where everything is.")
  val radio = Item("radio", "The engineer is on the other side and will help you tell which ship you are on.")
  val sail = Item("sail", "With the sails, you can move ships around.")
  val question = true //question is an alias for true
  val captain = Person("the captain", Some(mapItem))
  captain.addDialog("O-hoy! Nice to meet you. Listen up!") //line 0
    .addDialog("My ship's stuck! I need to exit the bay west...") //line 1
    .addDialog("But there's a ship in the way. Do you think you can help?", 4, question) //line 2
    .addDialog("Thank goodness! I knew you could help. I can give you my map. Oh, by the way,", 7) //line 3
    .addDialog("You can't? What am I meant to do? Maybe you can still try?", 6, question) //line 4
    .addDialog("Thanks for the effort. If everyone was as helpful, the world would be a nicer place. So...", 7) //line 5
    .addDialog("Dang. Well, I'll probably resign soon. You can have my map.") //line 6
    .addDialog("Maybe the engineer has more info? He's to the very north-east. But wait, the map...") //line 7
  mainShip.addPerson(1, 0, captain)
  val engineer = Person("the engineer", Some(radio))
  engineer.addDialog("Do you believe in ghosts?", question) //line 0
    .addDialog("Good. I don't.") //line 1
    .addDialog("But I did see something white around here. Scary, isn't it?", 4, question) //line 2
    .addDialog("You're a coward. That's what I'll think until...", 5) //line 3
    .addDialog("Of course not. I knew I could count on you to...") //line 4
    .addDialog("go to the center of Ship F and check the white thing out.") //line 5
    .addDialog("Which ship is Ship F? I'll hand you a radio soon. If you want to know which ship you're on, just call me.") //line 6
    .addDialog("You can see the ships on the map. Y'know, the captain had one of those too. Wait, the radio...") //line 7
  seaGrid(3)(0).addPerson(engineer)
  seaGrid(1)(3).addItem(sail)


  /** The number of turns that have passed since the start of the game. */
  var turnCount = 0
  /** The maximum number of turns that this adventure game allows before time runs out. */
  val timeLimit = 120


  /** Determines if the adventure is complete, that is, if the player has won. */
  def isComplete =
    mainShip.shipX == 0

  /** Determines whether the player has won, lost, or quit, thereby ending the game. */
  def isOver = this.isComplete || this.player.hasQuit || this.turnCount == this.timeLimit


  /** Returns a message that is to be displayed to the player at the beginning of the game. */
  def welcomeMessage = "Huh, apparently the ship you're on is stuck. Maybe you can help? Talk to the captain on the east side."

  /** Returns a message that is to be displayed to the player at the end of the game. The message
    * will be different depending on whether the player has completed their quest. */
  def goodbyeMessage =
    if this.isComplete then
      "Well done! The ship is free to leave the bay."
    else if this.turnCount == this.timeLimit then
      "Oh no! Time's up. You fall over the board and drown.\nGame over!"
    else  // game over due to player quitting
      "Quitter!"


  /** Plays a turn by executing the given in-game command, such as “go west”. Returns a textual
    * report of what happened, or an error message if the command was unknown. In the latter
    * case, no turns elapse. */
  def playTurn(command: String): String =
    val action = Action(command)
    val outcomeReport = action.execute(this.player)
    if outcomeReport.isDefined then
      this.turnCount += 1
    outcomeReport.getOrElse(s"""Unknown command: "$command".""")

end Adventure

object Adventure

end Adventure