package o1.adventure

import scala.collection.mutable.Map
import scala.collection.mutable.Buffer

/** A `Player` object represents a player character controlled by the real-life user
  * of the program.
  *
  * A player object’s state is mutable: the player’s location and possessions can change,
  * for instance.
  *
  * @param startingArea  the player’s initial location */
class Player(startingArea: Area):

  private var currentLocation = startingArea        // gatherer: changes in relation to the previous location
  private var quitCommandGiven = false              // one-way flag
  private val possessions = Map[String, Item]()     // container of all the items that the player has
  private var lastTalked : Option[String] = None

  /** Determines if the player has indicated a desire to quit the game. */
  def hasQuit: Boolean = this.quitCommandGiven

  /** Returns the player’s current location. */
  def location: Area = this.currentLocation


  /** Attempts to move the player in the given direction. This is successful if there
    * is an exit from the player’s current location towards the direction name. Returns
    * a description of the result: "You go DIRECTION." or "You can't go DIRECTION." */
  def go(direction: String): String =
    lastTalked = None
    val destination = this.location.neighbor(direction)
    this.currentLocation = destination.getOrElse(this.currentLocation)
    if destination.isDefined then s"You go $direction." else s"You can't go $direction."


  /** Causes the player to rest for a short while (this has no substantial effect in game terms).
    * Returns a description of what happened. */
  def rest(): String =
    "You rest for a while. Better get a move on, though."


  /** Signals that the player wants to quit the game. Returns a description of what happened
    * within the game as a result (which is the empty string, in this case). */
  def quit(): String =
    this.quitCommandGiven = true
    ""


  /** Returns a brief description of the player’s state, for debugging purposes. */
  override def toString = "Now at: " + this.location.name


  /** Tries to pick up an item of the given name. This is successful if such an item is
    * located in the player’s current location. If so, the item is added to the player’s
    * inventory and removed from the location. Returns a description of the result:
    * "You pick up the ITEM." or "There is no ITEM here to pick up." */
  def get(itemName: String): String =
    val received = this.location.removeItem(itemName)
    for newItem <- received do
      this.possessions.put(newItem.name, newItem)
    if received.isDefined then
      s"You pick up the $itemName."
    else
      s"There is no $itemName here to pick up."

  def receive(item: Item) =
    this.possessions.put(item.name, item)
  /** Determines whether the player is carrying an item of the given name. */
  def has(itemName: String): Boolean =
    this.possessions.contains(itemName)


  /** Tries to drop an item of the given name. This is successful if such an item is
    * currently in the player’s possession. If so, the item is removed from the
    * player’s inventory and placed in the area. Returns a description of the result
    * of the attempt: "You drop the ITEM." or "You don't have that!". */
  def drop(itemName: String): String =
    val removed = this.possessions.remove(itemName)
    for oldItem <- removed do
      this.location.addItem(oldItem)
    if removed.isDefined then s"You drop the $itemName." else "You don't have that!"


  /** Causes the player to examine the item of the given name. This is successful if such
    * an item is currently in the player’s possession. Returns a description of the result,
    * which, if the attempt is successful, includes a description of the item. The description
    * has the form: "You look closely at the ITEM.\nDESCRIPTION" or "If you want
    * to examine something, you need to pick it up first." */
  def examine(itemName: String): String =
    def lookText(item: Item) = "You look closely at the " + item.name + ".\n" + item.description
    val failText = "If you want to examine something, you need to pick it up first."
    this.possessions.get(itemName).map(lookText).getOrElse(failText)

  def inventory: String =
    if this.possessions.isEmpty then
      "You are empty-handed."
    else
      "You are carrying:\n" + this.possessions.keys.mkString("\n")

  def speak (name : String, words: Person => Player => String) : String =
    this.location.speak(name, words, this)

  def talk(name: String): String =
    lastTalked = Some(name)
    speak(name, _.advance)

  def continue(): String =
    lastTalked match
      case None => "Continue talking? To whom?"
      case Some(name) => talk(name)

  def repeat(): String =
    lastTalked match
      case None => "Who should repeat what?"
      case Some(name) => speak(name, _.repeat)

  def yes(): String =
    lastTalked match
      case None => "You exitedly shout 'yes!' to no one in particular."
      case Some(name) => speak(name, _.yes)

  def no(): String =
    lastTalked match
      case None => "In deep despair, you shout 'No!' to no one in particular."
      case Some(name) => speak(name, _.no)

  def sail(direction : String): String =
    if !has("sail") then
      return "No sail. Try to talking to the engineer?"
    val shipO = Ship.getShip(this.location)
    shipO match
      case None => "No ship here!"
      case Some(ship) => ship.sail(direction)

  def use(itemName: String) : String =
    if has(itemName) then
      if itemName == "map" then useMap
      else if itemName == "radio" then useRadio
      else if itemName == "sail" then "Try: sail [cardinal direction]"
      else "Not sure what to do with this."
    else
      "You do not have that item."

  def useMap : String =
    var res = "Here is the map: \n\n"
    for j <- 0 until Ship.seaSize do
      for i <- 0 until Ship.seaSize do
        res = res + ".ABCDEFGHIJ".toBuffer(Ship.getShip(Ship.seaGrid(i)(j)).map(s=>Ship.allShips.indexOf(s)+1).getOrElse(0))
      res += "\n"
    res

  def useRadio: String =
    Ship.getShip(location).map(s=>"You're on Ship "+"ABCDEFGHIJ".toBuffer(Ship.allShips.indexOf(s))+".")
      .getOrElse("You aren't on a ship.")

  def help() : String =
    "Here's the commands one can use: " +
       "rest, " +
       "quit, " +
       "drop [itemname], " +
       "get [itemname], " +
       "examine [itemname], " +
       "inventory, " +
       "talkto [personname], " +
       "continue (repeats last talkto), " +
       "yes, " +
       "no, " +
       "use, " +
       "sail [cardinal direction], " +
       "repeat, " +
       "help, " +
       "uuddlrlrbas (for cheating)"

  def uuddlrlrbas (): String =
    receive(Item("radio","cheatradio"))
    receive(Item("sail","cheatsail"))
    receive(Item("map","cheatmap"))
    "You cheated succesfully"

end Player